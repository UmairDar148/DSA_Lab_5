//#include <iostream>
//#include <string>
//#include "myQueue.h" 
//using namespace std;
//int main() {
//    myQueue<string> pQueue(50);
//    int choice;
//    string docName;
//    do {
//        cout << "1. Add new print job\n";
//        cout << "2. Print front document\n";
//        cout << "3. Check next document\n";
//        cout << "4. Display remaining jobs\n";
//        cout << "5. Exit\n";
//        cout << "Enter your choice (1-5): ";
//        cin >> choice;
//        switch (choice) {
//        case 1:
//            cout << "Enter document name (e.g., Assignment-01.pdf): ";
//            cin.ignore();
//            getline(cin, docName);
//            pQueue.enQueue(docName);
//            cout << "'" << docName << "' added to the print queue.\n";
//            break;
//        case 2:
//            if (!pQueue.isEmpty()) {
//                docName = pQueue.deQueue();
//                cout << "    PRINTING: '" << docName << endl;
//            }
//            else { pQueue.deQueue(); }
//            break;
//        case 3:
//            if (!pQueue.isEmpty()) {
//                cout << "Next document: '" << pQueue.front() << "'\n";
//            }
//            else { pQueue.front(); }
//            break;
//        case 4:
//            if (!pQueue.isEmpty()) {
//                cout << "Remaining Prints:\n";
//                pQueue.display();
//            }
//            else { cout << "Queue is Empty"; }
//            break;
//        case 5:
//            cout << "Exit\n";
//            break;
//        default:
//            cout << "Invalid choice! \nSelect a number between 1 and 5.\n";
//        }
//    } while (choice != 5);
//    return 0;
//}