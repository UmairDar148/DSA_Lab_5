#include <iostream>
#include <string>
#include "myQueue.h"
using namespace std;
void timeToDeliver(myQueue<int>& idQ, myQueue<string>& addrQ, myQueue<int>& startQ, myQueue<int>& endQ, int currentTime) {
    if (idQ.isEmpty()) {
        cout << "Queue Empty!\n";
        return;
    }
    string frontAddr = addrQ.front();
    int fId = idQ.front(), fStart = startQ.front(), fEnd = endQ.front();
    cout << "\nProcessing ID: " << fId << "\n";
    if (currentTime > fEnd) {
        cout << "EXPIRED! Time passed. Removing...\n";
        idQ.deQueue(); addrQ.deQueue(); startQ.deQueue(); endQ.deQueue();
    }
    else if (currentTime >= fStart && currentTime <= fEnd) {
        cout << "DELIVERED to " << frontAddr << "!\n";
        idQ.deQueue(); addrQ.deQueue(); startQ.deQueue(); endQ.deQueue();
    }
    else { cout << "PENDING. Too early. Leaving in queue...\n"; }
}
void displayAllPackages(myQueue<int>& idQ, myQueue<string>& addrQ, myQueue<int>& startQ, myQueue<int>& endQ) {
    if (idQ.isEmpty()) {
        cout << "Queue Empty!\n";
        return;
    }
    int n = getQueueSize(idQ);
    cout << "Queued Packages:\n";
    for (int i = 0; i < n; i++) {
        int id = idQ.deQueue();
        string addr = addrQ.deQueue();
        int start = startQ.deQueue();
        int end = endQ.deQueue();
        cout << "[" << id << " | " << addr << " | " << start << ":00 - " << end << ":00]\n";
        idQ.enQueue(id);
        addrQ.enQueue(addr);
        startQ.enQueue(start);
        endQ.enQueue(end);
    }
}
int main() {
    myQueue<int> idQueue(50);
    myQueue<string> addressQueue(50);
    myQueue<int> startTimeQueue(50);
    myQueue<int> endTimeQueue(50);

    int choice, currentTime;
    cout << "Enter the current time: ";
    cin >> currentTime;
    do {
        cout << "Current Time: " << currentTime << ":00\n";
        cout << "1. Enqueue (Add new package)\n";
        cout << "2. Process Front Package\n";
        cout << "3. Inspect Front Package\n";
        cout << "4. Display all queued packages\n";
        cout << "5. Fast-Forward Time (+1 hour)\n";
        cout << "6. Exit\n";
        cout << "Enter your choice (1-6): ";
        cin >> choice;
        switch (choice) {
        case 1: {
            int id, start, end;
            string addr;
            cout << "Enter Package ID: ";
            cin >> id;
            cout << "Enter Delivery Address: ";
            cin >> ws;
            getline(cin, addr);
            cout << "Enter Start Time (e.g. 10): ";
            cin >> start;
            cout << "Enter End Time (e.g. 14): ";
            cin >> end;
            idQueue.enQueue(id);
            addressQueue.enQueue(addr);
            startTimeQueue.enQueue(start);
            endTimeQueue.enQueue(end);
            cout << "Package added!\n";
            break;
        }
        case 2:
            timeToDeliver(idQueue, addressQueue, startTimeQueue, endTimeQueue, currentTime);
            break;
        case 3:
            if (!idQueue.isEmpty()) {
                cout << "Front Package:\n";
                cout << "[" << idQueue.front() << " | " << addressQueue.front()
                    << " | " << startTimeQueue.front() << ":00 - " << endTimeQueue.front() << ":00]\n";
            }
            else { idQueue.front(); }
            break;
        case 4:
            displayAllPackages(idQueue, addressQueue, startTimeQueue, endTimeQueue);
            break;
        case 5:
            currentTime++;
            if (currentTime > 24) { currentTime = 1; }
            cout << "Time advanced. Current time is now " << currentTime << ":00.\n";
            break;
        case 6:
            cout << "System closed. Allah Hafiz!\n";
            break;
        default:
            cout << "Invalid choice!\n";
        }
    } while (choice != 6);
    return 0;
}