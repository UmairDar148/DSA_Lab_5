#include"myQueue.h"
#include"QueueStack.h"
void reverseFirstK(myQueue<int>& q, int k) {
	if (q.isEmpty() || k <= 1) { return; }
	int n = getQueueSize(q);
	if (k > n) { k = n; }
	Stack<int>s(k);
	for (int i = 0;i < k;i++) { s.push(q.deQueue()); }
	while (!s.isEmpty()) { q.enQueue(s.pop()); }
	for (int i = 0;i < n - k;i++) { q.enQueue(q.deQueue()); }
}
int main() {
    int totalElements, k, val;
    cout << "Enter the total number of elements in the Queue: ";
    cin >> totalElements;
    myQueue<int> q(20);
    cout << "Enter the " << totalElements << " elements of the Queue:\n";
    for (int i = 0; i < totalElements; i++) {
        cin >> val;
        q.enQueue(val);
    }
    cout << "Enter K: ";
    cin >> k;
    cout << "\nOriginal ";
    q.display();
    cout << "K = " << k << endl;
    reverseFirstK(q, k);
    cout << "\nOutput ";
    q.display();
    return 0;
}