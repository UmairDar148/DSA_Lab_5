#include <iostream>
#include "myQueue.h"
using namespace std;
int main() {
    myQueue<int> tQueue(100);
    int choice,t_id;
    do {
        cout << "1. Add a new ticket\n";
        cout << "2. Resolve ticket\n";
        cout << "3. Check next ticket\n";
        cout << "4. Display all pending tickets\n";
        cout << "5. Exit\n";
        cout << "Enter your choice (1-5): ";
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "Enter 4-digit Ticket ID: ";
            cin >> t_id;
            if (t_id >= 1000 && t_id <= 9999) {
                tQueue.enQueue(t_id);
                cout << "Ticket #" << t_id << " added successfully to the queue\n";
            }
            else { cout << "Invalid ID! \nPlease enter a valid 4-digit number.\n"; }
            break;
        case 2:
            if (!tQueue.isEmpty()) {
                t_id = tQueue.deQueue();
                cout << "Ticket #" << t_id << " has been removed\n";
            }
            else { cout << "Queue is Empty\n"; }
            break;
        case 3:
            if (!tQueue.isEmpty()) {
                cout << "Next ticket to be resolved is: Ticket #" << tQueue.front() << endl;
            }
            else { cout << "Queue is Empty\n"; }
            break;
        case 4:
            if (!tQueue.isEmpty()) {
                cout << "Pending Tickets:\n";
                tQueue.display();
            }
            else { cout << "Queue is Empty\n"; }
            break;
        case 5:
            cout << "Exit\n";
            break;
        default:
            cout << "Invalid choice!\n Select a number between 1 and 5.\n";
        }
    } while (choice != 5);
    return 0;
}