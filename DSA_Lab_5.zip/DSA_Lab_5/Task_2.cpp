#include <iostream>
#include "QueueStack.h"
using namespace std;
int main() {
    Queue<int> q;
    int choice, value;
    do {
        cout << "\n      QUEUE MENU \n\n";
        cout << "1. Add element\n";
        cout << "2. Remove element\n";
        cout << "3. Front Element\n";
        cout << "4. Check if Empty\n";
        cout << "5. Display Queue\n";
        cout << "6. Exit\n";
        cout << "Enter your choice (1-6): ";
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "Enter an integer value to enqueue: ";
            cin >> value;
            q.enQueue(value);
            cout << value << " has been enqueued successfully.\n";
            break;
        case 2:
            if (!q.isEmpty()) {
                value = q.deQueue();
                cout << "Dequeued value: " << value << endl;
            }
            else { q.deQueue(); }
            break;
        case 3:
            if (!q.isEmpty()) { cout << "Front element is: " << q.front() << endl; }
            else { q.front(); }
            break;
        case 4:
            if (q.isEmpty()) { cout << "The queue is currently empty.\n"; }
            else { cout << "The queue is NOT empty.\n"; }
            break;
        case 5:
            q.display();
            break;
        case 6:
            cout << "Exit\n";
            break;
        default:
            cout << "Invalid choice! \nEnter a number between 1 and 6.\n";
        }
    } while (choice != 6);
    return 0;
}