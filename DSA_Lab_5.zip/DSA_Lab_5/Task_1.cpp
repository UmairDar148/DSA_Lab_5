#include <iostream>
#include "myQueue.h"
using namespace std;
int main() {
    int size;
    cout << "Enter the maximum capacity for your queue: ";
    cin >> size;
    myQueue<int> q(size);
    int choice;
    int value;
    do {
        cout << "1. Add element\n";
        cout << "2. Remove element\n";
        cout << "3. Front Element\n";
        cout << "4. Check if Empty\n";
        cout << "5. Check if Full\n";
        cout << "6. Display Queue\n";
        cout << "7. Exit\n";
        cout << "Enter your choice (1-7): ";
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "Enter an integer value to enqueue: ";
            cin >> value;
            q.enQueue(value);
            break;
        case 2:
            if (!q.isEmpty()) {
                value = q.deQueue();
                cout << "Dequeued value: " << value << endl;
            }
            else { q.deQueue(); }
            break;
        case 3:
            if (!q.isEmpty()) { cout << "Front element is: " << q.front() << endl; }
            else { q.front(); }
            break;
        case 4:
            if (q.isEmpty()) { cout << "The queue is  empty\n"; }
            else { cout << "The queue is NOT empty\n"; }
            break;
        case 5:
            if (q.isFull()) { cout << "The queue is currently full.\n"; }
            else { cout << "The queue is NOT full\n"; }
            break;
        case 6:
            q.display();
            break;
        case 7:
            cout << "Exit\n";
            break;
        default:
            cout << "Invalid choice! \nEnter a number between 1 and 7\n";
        }
    } while (choice != 7);
    return 0;
}