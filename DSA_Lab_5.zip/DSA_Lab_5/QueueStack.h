#pragma once
#include <iostream>
using namespace std;
template<typename T>
class Stack {
private:
    T* arr;
    int capacity, top;
public:
    Stack(int size = 10) : capacity(size) {
        arr = new T[size];
        top = -1;
    }
    ~Stack() { delete[] arr; }
    Stack(const Stack<T>& s) {
        capacity = s.capacity;
        top = s.top;
        arr = new T[capacity];
        for (int i = 0; i <= top; i++) { arr[i] = s.arr[i]; }
    }
    Stack& operator=(const Stack& s) {
        if (this != &s) {
            delete[] arr;
            capacity = s.capacity;
            top = s.top;
            arr = new T[capacity];
            for (int i = 0; i <= top; i++) {
                arr[i] = s.arr[i];
            }
        }
        return *this;
    }
    void push(T val) {
        if (top < capacity - 1) {
            arr[top + 1] = val;
            top++;
        }
        else { cout << "Stack Overflow!\n"; }
    }
    T pop() {
        if (top >= 0) { return arr[top--]; }
        return T();
    }
    T Top() {
        if (top >= 0) { return arr[top]; }
        return T();
    }
    bool isEmpty() { return (top == -1); }
};
template<typename T>
class Queue {
private:
    Stack<T> s1;
    Stack<T> s2;
    void Copy() {
        while (!s1.isEmpty()) {s2.push(s1.pop()); }
    }
public:
    void enQueue(T value) { s1.push(value); }
    T deQueue() {
        if (s1.isEmpty() && s2.isEmpty()) {
            cout << "Queue is Empty!!!\n";
            return T();
        }
        if (s2.isEmpty()) { Copy(); }
        return s2.pop();
    }
    T front() {
        if (s1.isEmpty() && s2.isEmpty()) {
            cout << "Queue is Empty!!!\n";
            return T();
        }
        if (s2.isEmpty()) { Copy(); }
        return s2.Top();
    }
    bool isEmpty() { return (s1.isEmpty() && s2.isEmpty()); }
    void display() {
        if (isEmpty()) {
            cout << "Queue is Empty!!!\n";
            return;
        }
        cout << "Queue: ";
        Stack<T> t2 = s2;
        for (; !t2.isEmpty(); ) {
            cout << t2.Top() << " ";
            t2.pop();
        }
        Stack<T> t1 = s1;
        Stack<T> revT1;
        while (!t1.isEmpty()) {
            revT1.push(t1.pop());
        }
        while (!revT1.isEmpty()) {
            cout << revT1.Top() << " ";
            revT1.pop();
        }
        cout << endl;
    }
};