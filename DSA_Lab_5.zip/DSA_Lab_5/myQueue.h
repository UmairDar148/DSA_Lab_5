#pragma once
#include <iostream>
using namespace std;
template <typename T>
class AbstractQueue {
public:
    virtual void enQueue(T value) = 0;
    virtual T deQueue() = 0;
    virtual T front() const = 0;
    virtual bool isEmpty() const = 0;
    virtual bool isFull() const = 0;
    virtual ~AbstractQueue() {}
};
template<typename T>
class myQueue : public AbstractQueue<T> {
private:
    T* arr;
    int capacity,frontInd, lastAddEl,count;
public:
    myQueue(int size) : capacity(size) {
        arr = new T[capacity];
        frontInd = 0;
        lastAddEl = -1;
        count = 0;
    }
    ~myQueue() override {
        delete[] arr;
    }
    bool isEmpty() const override {
        return (count == 0);
    }
    bool isFull() const override {
        return (count == capacity);
    }
    void enQueue(T value) override {
        if (isFull()) {
            cout << "Queue is Full!!!" << endl;
            return;
        }
        lastAddEl = (lastAddEl + 1) % capacity;
        arr[lastAddEl] = value;
        count++;
    }
    T deQueue() override {
        if (isEmpty()) {
            cout << "Queue is Empty!!!\n";
            return T();
        }
        T val = arr[frontInd];
        frontInd = (frontInd + 1) % capacity;
        count--;
        return val;
    }
    T front() const override {
        if (isEmpty()) {
            cout << "Queue is Empty!!!\n";
            return T();
        }
        return arr[frontInd];
    }
    void display() const {
        if (isEmpty()) {
            cout << "Queue is Empty!!!\n";
            return; 
        }
        cout << "Queue: ";
        int ind = frontInd;
        for (int i = 0; i < count; i++) {
            cout << arr[ind] << " ";
            ind = (ind + 1) % capacity;
        }
        cout << endl;
    }
};
int getQueueSize(myQueue<int>& q) {
    myQueue<int>t(20);
    int count = 0;
    while (!q.isEmpty()) {
        t.enQueue(q.deQueue());
        count++;
    }
    while (!t.isEmpty()) { q.enQueue(t.deQueue()); }
    return count;
}